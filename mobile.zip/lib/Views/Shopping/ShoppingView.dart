import 'package:fahkapmobile/components/Button/AppIconButton.dart';
import 'package:fahkapmobile/components/Button/IconButtonF.dart';
import 'package:fahkapmobile/components/Button/customBtn.dart';
import 'package:fahkapmobile/components/Text/bigText.dart';
import 'package:fahkapmobile/components/Widget/categoryComponent.dart';
import 'package:fahkapmobile/components/Text/smallText.dart';
import 'package:fahkapmobile/components/Widget/shoppingproductComponent.dart';
import 'package:fahkapmobile/controller/cartController.dart';
import 'package:fahkapmobile/styles/colorApp.dart';
import 'package:fahkapmobile/styles/textStyle.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShoppingView extends StatelessWidget {
  ShoppingView({Key? key}) : super(key: key);
  ScrollController _scrollController = new ScrollController();

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CartController>(builder: (_controller) {
      return Scaffold(
        body: _controller.getItems.length == 0
            ? Center(
                child: BigText(
                  text: 'Vide',
                  bolder: true,
                ),
              )
            :  CustomScrollView(controller: _scrollController, slivers: [
                // Add the app bar to the CustomScrollView.
                // SliverAppBar(
                //   backgroundColor: ColorsApp.bleuLight,
                //   title: Row(
                //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //     children: [
                //       IconButtonF(
                //         icon: Icons.close,
                //         color: ColorsApp.black,
                //         onTap: () {
                //           Get.back();
                //         },
                //       ),
                //       IconButtonF(
                //         color: ColorsApp.black,
                //         icon: Icons.shopping_cart_outlined,
                //         onTap: () {
                //           Get.back();
                //         },
                //       ),
                //     ],
                //   ),

                //   // expandedHeight: 300,
                //   // pinned: true,
                // ),
                SliverList(
                    delegate: SliverChildBuilderDelegate(
                  (context, index) => ShoppingproductComponent(
                    cartM: _controller.getItems[index],
                  ),
                  childCount: _controller.getItems.length,
                ))
              ]),
        bottomNavigationBar: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              decoration: BoxDecoration(color: ColorsApp.grey),
              padding: EdgeInsets.only(
                  left: kMdWidth / 6, right: kMdWidth / 6, top: 6, bottom: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    // width: Get.size.width * 0.1,
                    alignment: Alignment.center,
                    padding: EdgeInsets.all(10),
                    // margin: EdgeInsets.all(10),
                    decoration: new BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    child: Text(
                      '${_controller.totalPrix} XAF',
                      style: TextStyle(
                          fontFamily: 'orkney',
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  CustomBtn(
                    color: ColorsApp.greenLight,
                    title: 'Buy',
                  )
                ],
              ),
            )
          ],
        ),
      );
    });
  }
}
