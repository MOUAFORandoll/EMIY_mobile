import 'package:Fahkap/controller/ShortController.dart';
import 'package:Fahkap/styles/colorApp.dart';
import 'package:Fahkap/styles/textStyle.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get_state_manager/src/simple/get_state.dart';

class ShortAction extends StatelessWidget {
  ShortAction({this.validate = false, this.icon, this.onTap, this.title});
  var validate, icon, onTap, title;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ShortController>(
        builder: (_ShortController) => Container(
                // alignment: Alignment.center,
                // padding: EdgeInsets.all(7),
                // decoration: BoxDecoration(
                //     borderRadius: BorderRadius.circular(50),
                //     border: Border.all(
                //       color: Colors.white,
                //     )),
                // color: Colors.red,
                child: Column(
              children: [
                Container(
                    width: 48,
                    height: 48,
                    margin: EdgeInsets.symmetric(
                        vertical: kMarginY * 2, horizontal: kMarginX),
                    child: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 50,
                        backgroundImage:
                            AssetImage("assets/images/error.gif"))),
                InkWell(
                  child: Container(
                    margin: EdgeInsets.symmetric(
                        vertical: kMarginY * 2, horizontal: kMarginX),
                    child: Icon(
                      Icons.favorite,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  onTap: () {
                    print(_ShortController
                        .listShort[_ShortController.currentShort].id);
                  },
                ),
                Container(
                    margin: EdgeInsets.symmetric(
                        vertical: kMarginY * 2, horizontal: kMarginX),
                    child: Icon(
                      FontAwesomeIcons.solidComment,
                      color: Colors.white,
                      size: 40,
                    )),
                Container(
                    margin: EdgeInsets.symmetric(
                        vertical: kMarginY * 2, horizontal: kMarginX),
                    child: Icon(
                      FontAwesomeIcons.share,
                      color: Colors.white,
                      size: 40,
                    ))
              ],
            )));
  }
}
