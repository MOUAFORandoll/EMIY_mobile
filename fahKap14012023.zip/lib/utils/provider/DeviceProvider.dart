import 'package:get/get.dart';

abstract class DeviceProvider {
  var height = Get.height;
  var width = Get.width;
}
