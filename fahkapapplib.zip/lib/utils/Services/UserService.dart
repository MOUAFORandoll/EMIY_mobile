import 'dart:convert';

import 'package:fahkapmobile/utils/Services/storageService.dart';

class UserService extends StorageService {
  final nom = UserService().getUser().nom;
  final prenom = UserService().getUser().prenom;
  final phone = UserService().getUser().phone;
  final status = UserService().getUser().status;
  final agences = UserService().getUser().agences;
  final pointDeVentes = UserService().getUser().pointDeVentes;
  final typeUser = UserService().getUser().typeUser;
  final id = UserService().getUser().id;
}
