class ApiUrl {
  static final String backUrl = "http://172.20.10.10";
  // static final String baseUrl = backUrl + ":81";
  // static final String socketUrl = backUrl + ":82";
  // static final String stream_serveurUrl = backUrl + ":83";
  // static final String backUrl = "http://192.168.137.219";
  static final String baseUrl = backUrl + ":8000";
  static final String socketUrl = backUrl + ":3000";
  static final String stream_serveurUrl = backUrl + ":4000";
  static final String external_link = "https://emiy-shop.000webhostapp.com/";

  //656332160  produitqzZhJ
}
