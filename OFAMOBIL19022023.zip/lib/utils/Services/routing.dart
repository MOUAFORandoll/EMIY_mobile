import 'package:Fahkap/Views/BoutiqueUser/BoutiqueNewView.dart';
import 'package:Fahkap/Views/BoutiqueUser/CommadesBoutiqueUserView.dart';
import 'package:Fahkap/Views/UsersMange/CompteView.dart';
import 'package:Fahkap/Views/BoutiqueUser/HistroriqueCBUView.dart';
import 'package:Fahkap/Views/BoutiqueUser/manageBoutiqueUserView.dart';
import 'package:Fahkap/Views/BoutiqueUser/produitBoutiqueUserView.dart';
import 'package:Fahkap/Views/CategoryBoutique/BoutiqueCategoryView.dart';
import 'package:Fahkap/Views/CategoryBoutique/BoutiqueView.dart';
import 'package:Fahkap/Views/Commandes/CommandeView.dart';
import 'package:Fahkap/Views/Commandes/ProduitForCommande.dart';
import 'package:Fahkap/Views/ComplementView/OnboardingScreen.dart';
import 'package:Fahkap/Views/FirstScreen.dart';
import 'package:Fahkap/Views/ComplementView/SplashScreen.dart';
import 'package:Fahkap/Views/Home/HomeView.dart';
import 'package:Fahkap/Views/Home/ListBoutiquesView.dart';
import 'package:Fahkap/Views/Home/ListProduitsView.dart';
import 'package:Fahkap/Views/Product/ProductView.dart';
import 'package:Fahkap/Views/Shopping/BuyShoopingCart.dart';
import 'package:Fahkap/Views/Shopping/ShoppingView.dart';
import 'package:Fahkap/Views/Shopping/ShoppingViewNext.dart';
import 'package:Fahkap/Views/UsersMange/RegisterScreen.dart';
import 'package:Fahkap/Views/UsersMange/SettingView.dart';
import 'package:Fahkap/Views/UsersMange/forgotPassword.dart';
import 'package:flutter/material.dart';
import 'package:Fahkap/Views/UsersMange/LoginScreen.dart';
import 'package:Fahkap/Views/ComplementView/AboutUsView.dart';
// import 'package:Fahkap/Views/Home/AcheterBillet.dart';
import 'package:get/get.dart';

import '../../test.dart';

var transitionX = Transition.zoom;

class AppRoutes {
  static final pages = [
    GetPage(
        name: AppLinks.FIRST,
        page: () => FirstScreen(),
        transition: transitionX),
    GetPage(
        name: AppLinks.LOGIN,
        page: () => LoginScreen(),
        transition: transitionX),
    GetPage(
        name: AppLinks.HOME,
        children: [],
        page: () => HomeView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.REGISTER,
        page: () => RegisterScreen(),
        transition: transitionX),
    GetPage(
      name: AppLinks.FORGOT,
      page: () => ForgotPassordScreen(),
      transition: transitionX,
    ),
    GetPage(
        name: AppLinks.CART,
        page: () => ShoppingView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.BUYSHOP,
        page: () => BuyShoopingCart(),
        transition: transitionX),
    // GetPage(name: AppLinks.ABOUTUS, page: () => AboutUsScreen(),  transition:transitionX),
    GetPage(
        name: AppLinks.SPLASHSCREEN,
        page: () => SplashScreenPage(),
        transition: transitionX),
    GetPage(name: AppLinks.TEST, page: () => Test()),
    GetPage(
        name: AppLinks.ONBOARDING,
        page: () => Onboarding(),
        transition: transitionX),
    GetPage(
        name: AppLinks.PRODUCT,
        // ignore: top_level_function_literal_block
        page: () {
          var index = Get.parameters['index'];
          return ProductView(index: int.parse(index!));
        },
        transition: transitionX),
    GetPage(
        name: AppLinks.PRODUCT_FOR_COMMANDE,
        // ignore: top_level_function_literal_block
        page: () {
          var id = Get.parameters['id'];
          var code = Get.parameters['code'];
          return ProduitForCommande(id: int.parse(id!), code: code!);
        },
        transition: transitionX),
    GetPage(
        name: AppLinks.BOUTIQUE,
        // ignore: top_level_function_literal_block
        page: () {
          return BoutiqueView();
        },
        transition: transitionX),
    GetPage(
        name: AppLinks.BOUTIQUE_FOR_CATEGORY,
        page: () => BoutiqueCategoryView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.PRODUCT_FOR_BOUTIQUE,
        page: () => ProduitBoutiqueUserView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.COMMANDE_FOR_BOUTIQUE,
        page: () => CommandesBoutiqueUserView(),
        transition: transitionX),

    GetPage(
        name: AppLinks.COMMANDE_FOR_USER,
        page: () => CommandeView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.HISTORIQUE_FOR_BOUTIQUE,
        page: () => HistroriqueCBUView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.MANAGE_FOR_BOUTIQUE,
        page: () => ManageBoutiqueUserView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.SHOPNEXT,
        page: () => ShoppingViewNext(),
        transition: transitionX),

    GetPage(
        name: AppLinks.BOUTIQUE_READ_ALL,
        page: () => ListBoutiquesView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.COMPTE_FOR_BOUTIQUE,
        page: () => CompteView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.PRODUCT_READ_ALL,
        page: () => ListProduitsView(),
        transition: transitionX),
    GetPage(
        name: AppLinks.SETTING,
        page: () => SettingView(),
        transition: transitionX),

          GetPage(
        name: AppLinks.BOUTIQUE_NEW,
        page: () => BoutiqueNewView(),
        transition: transitionX),
  ];
}

class AppLinks {
  static const String PRODUCT_FOR_COMMANDE = "/pfc";
  static const String BOUTIQUE = "/boutique";
  static const String BOUTIQUE_NEW = "/boutique/new";
  static const String MANAGE_FOR_BOUTIQUE = "/mfb";
  static const String COMPTE_FOR_BOUTIQUE = "/cb";
  static const String SETTING = "/setting";
  static const String HISTORIQUE_FOR_BOUTIQUE = "/hfb";
  static const String COMMANDE_FOR_BOUTIQUE = "/cfb";
  static const String COMMANDE_FOR_USER = "/cfu";
  static const String PRODUCT_FOR_BOUTIQUE = "/pfb";
  static const String BUYSHOP = "/buyShop";
  static const String SHOPNEXT = "/shop";
  static const String TEST = "/TEST";
  static const String LOGIN = "/login";
  static const String HOME = "/home";
  static const String REGISTER = "/register";
  static const String ABOUTUS = "/aboutus";
  static const String FORGOT = "/forgot";
  static const String FIRST = "/first";
  static const String CART = "/cart";
  static const String SPLASHSCREEN = "/splashscreen";
  static const String ONBOARDING = "/onboarding";
  static const String PRODUCT = "/product";
  static const String BOUTIQUE_FOR_CATEGORY = "/bfc";
  static const String BOUTIQUE_READ_ALL = "/bra";
  static const String PRODUCT_READ_ALL = "/pra";
}
