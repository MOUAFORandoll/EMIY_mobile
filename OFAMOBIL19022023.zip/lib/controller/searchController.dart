import 'package:flutter/material.dart';
import 'package:get/get_connect/http/src/response/response.dart';

import 'package:Fahkap/controller/cartController.dart';
import 'package:Fahkap/model/data/ProduitModel.dart';
import 'package:Fahkap/repository/popularProductRepo.dart';
import 'package:Fahkap/styles/colorApp.dart';
import 'package:Fahkap/utils/Services/requestServices.dart';
import 'package:get/get.dart';

class SearchController extends GetxController {
  SearchController();
  int _tsearch = 0;
  int get tsearch => _tsearch;

  searchType(int i) {
    if (i == 0) {
      _controllerField.text = '';
    }
    _tsearch = i;
    update();
    print(_tsearch);
  }

  TextEditingController _controllerField = TextEditingController();
  TextEditingController get controllerField => _controllerField;

  bool _searchPro = false;
  bool get searchPro => _searchPro;

  searchProButtom() {
    // _searchPro = !_searchPro;
    // if (!_searchPro) {
    //   _produitList = _produitListSave;
    // }
    // // searchProduit('');
    // update();
  }

  searchProduit(text) {
    // _produitList = [];
    // List<ProduitModel> cont = [];
    // print(_produitListSave);

    // _produitListSave.forEach((item) {
    //   print(item.titre.toUpperCase());
    //   print(text.toUpperCase());
    //   if (item.titre.toUpperCase().contains(text.toUpperCase()) ||
    //       item.codeProduit.toUpperCase().contains(text.toUpperCase())) {
    //     cont.add(item);
    //   }
    // });
    // print(cont.length);
    // if (cont.length != 0) {
    //   _produitList = cont;
    // } else {
    //   _produitList = _produitListSave;
    // }

    update();
  }
}
