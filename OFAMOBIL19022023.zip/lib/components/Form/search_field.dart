import 'package:Fahkap/controller/searchController.dart';
import 'package:Fahkap/styles/colorApp.dart';
import 'package:Fahkap/styles/textStyle.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_utils/src/extensions/string_extensions.dart';

// ignore: must_be_immutable
class KSearchField extends StatelessWidget {
  final TextEditingController controllerField;
  final String? title;
  final prefix;
  final String? type;
  Function? onChange;
  final double? dim;
  bool isCode;

  KSearchField(
      {Key? key,
      required this.controllerField,
      this.title,
      this.prefix,
      this.type,
      this.dim,
      this.isCode = false,
      this.onChange})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SearchController>(builder: (searchCont) {
      return Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          color: ColorsApp.greySecond,
        ),

        height: kToolbarHeight / 1.7,
        width: kMdWidth * 2,
        // padding: EdgeInsets.symmetric(horizontal: 10),
        child: TextField(
          onChanged: (String value) {
            if (onChange != null) onChange!(value);
          },
          // cursorHeight: 30.0,
          controller: controllerField,
          textAlign: TextAlign.left,
          decoration: InputDecoration(
            prefix: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: ColorsApp.greySearch,
                ),
                // height: searchCont.tsearch == 0 ? 0 : kToolbarHeight / 1.9,
                width: searchCont.tsearch == 0 ? 0 : kMdWidth * 0.5,
                margin: EdgeInsets.only(left: 3).add(
                  EdgeInsets.symmetric(vertical: 0),
                ),
                padding: EdgeInsets.symmetric(horizontal: 5, vertical: 3),
                child: searchCont.tsearch == 1
                    ? Text(
                        'produit',
                        style: TextStyle(color: Colors.red, fontSize: 14),
                      )
                    : searchCont.tsearch == 2
                        ? Text(
                            'boutique',
                            style: TextStyle(color: Colors.red, fontSize: 14),
                          )
                        : searchCont.tsearch == 3
                            ? Text(
                                'categorie',
                                style:
                                    TextStyle(color: Colors.red, fontSize: 14),
                              )
                            : null),
            suffix: searchCont.controllerField.text.length != 0
                ? InkWell(
                    child: Container(
                      // decoration: BoxDecoration(
                      //   borderRadius: BorderRadius.circular(5),
                      //   color: ColorsApp.greySearch,
                      // ),
                      // height: searchCont.tsearch == 0 ? 0 : kToolbarHeight / 1.9,
                      //  width: searchCont.tsearch == 0 ? 0 : kMdWidth * 0.5,
                      // margin: EdgeInsets.only(left: 3),
                      margin: EdgeInsets.symmetric(horizontal: 5, vertical: 15),
                      child: Icon(Icons.close),
                    ),
                    onTap: () {
                      searchCont.searchType(0);
                    },
                  )
                : null,
            hintText: isCode ? '1234' : 'Recherche',
            border: OutlineInputBorder(
              borderSide: BorderSide.none,
              borderRadius: BorderRadius.zero,
            ),
            prefixStyle: TextStyle(color: Colors.grey, fontSize: 14),
            contentPadding: EdgeInsets.symmetric(vertical: 10),
            hintStyle: TextStyle(color: Colors.grey, fontSize: 14),
          ),
        ),
      );
    });
  }
}
