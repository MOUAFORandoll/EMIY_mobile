import 'package:Fahkap/styles/colorApp.dart';
import 'package:Fahkap/styles/textStyle.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_utils/src/extensions/string_extensions.dart';

// ignore: must_be_immutable
class SeacrhIngCompo extends StatelessWidget {
  final String? title;
  final onTap;

  SeacrhIngCompo({
    Key? key,
    this.onTap,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
        child: Container(
            margin: EdgeInsets.only(top: kMarginX),
            child: Row(
                // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                      margin: EdgeInsets.only(right: 10),
                      child: Icon(
                        Icons.search,
                        color: Colors.blue,
                      )),
                  //
                  Text(title!),
                  // Container(
                  //     margin: EdgeInsets.only(right: 10),
                  //     child: Icon(
                  //       Icons.search,
                  //       color: Colors.blue,
                  //     ))
                ])),
        onTap: onTap);
  }
}
