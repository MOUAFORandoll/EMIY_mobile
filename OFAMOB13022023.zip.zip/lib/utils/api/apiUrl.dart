class ApiUrl {
  // static final String baseUrl = "http://127.0.0.1:8000";
  // static final String baseUrl = "http://192.168.8.105:8000";
  static final String baseUrl = "http://192.168.8.103:8000";
  // static final String baseUrl = "http://api.fahkap.com";
}