class ApiUrl {
  // static final String baseUrl = "http://127.0.0.1:8000";
  // static final String baseUrl = "http://192.168.8.102:8000";
  static final String baseUrl = "http://192.168.8.100:8000";
}
