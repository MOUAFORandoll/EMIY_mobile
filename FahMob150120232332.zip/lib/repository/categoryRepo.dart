import 'package:fahkapmobile/model/data/ProduitModel.dart';
import 'package:fahkapmobile/utils/Services/ApiClient.dart';
import 'package:fahkapmobile/utils/constants/apiRoute.dart';
import 'package:get/get.dart';
import 'package:get/get_connect/http/src/response/response.dart';

class CategoryRepo extends GetxService {
  final ApiClient apiClient;
  CategoryRepo({required this.apiClient});

  Future getListCategory() async {
    Response a = await apiClient.getCollections(ApiRoutes.CATEGORY_PRODUCT);
    print(a.body);
    return a;
  }
}
